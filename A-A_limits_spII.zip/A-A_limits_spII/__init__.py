# -*- coding: utf-8 -*-
"""
Created on Mon Jan 16 12:43:51 2017

@author: Arkady
"""

