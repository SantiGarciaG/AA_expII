from constants import *
from avoidance_exp import AvoidanceExp

avoid_exp = AvoidanceExp()
avoid_exp.run_exp(test_mode=True) # =True means practice and baseline blocks are skipped
